({
   jsLoaded:
    function(component, event, helper) {
        // Set initial map parameters
        var map = L.map('map', {zoomControl: true, tap: false})
                  
        
        //Instantiate the map
        L.tileLayer(
       'https://server.arcgisonline.com/ArcGIS/rest/services/World_Street_Map/MapServer/tile/{z}/{y}/{x}',
       {
              attribution: 'Tiles © Esri'
       }).addTo(map);
        
        
        //Set default view of the map to TIP HQ Amsterdam
                //map.setView([52.311828,4.939566], 12);
        
        //Set default view to Scott Moore's location
                map.setView([52.7003,1.3626], 12); 
        
        // Set default view of the map based on the users' location 
                 //map.locate({setView: true,  maxZoom: 16});  
      
        component.set("v.map", map);
  },
    accountsLoaded: function(component, event, helper) {
        // Add markers
        var map = component.get('v.map');
        var accounts = event.getParam('accounts');
        for (var i=0; i<accounts.length; i++) {
            var account = accounts[i];
            var popupInfo = [account.name];
            var latLng = [account.ShippingLatitude, account.ShippingLongitude];
            // To display account name and status in the text balloon
            L.marker(latLng, {account: account}).addTo(map)
             .bindPopup(account.Name + "<br />" + 
                        account.AccountStatus__c + "<br />" +
                       	account.Segment__c + ", Fleet size= " + account.Customer_Fleet_Size__c);
        }  
    },
    accountSelected: function(component, event, helper) {
    // Center the map on the account selected in the list
    var map = component.get('v.map');
    var account = event.getParam("account");
    map.panTo([account.ShippingLatitude, account.ShippingLongitude]);
}
})