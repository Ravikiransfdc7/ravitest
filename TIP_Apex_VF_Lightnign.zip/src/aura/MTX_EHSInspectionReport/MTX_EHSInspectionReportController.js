({
    
    showHeader : function(component, event, helper) {
        helper.showHeaderHelper(component);
    },
    
    showQuestions : function(component,event,helper){
        console.log(event.target.id);
        var targetId=event.target.id;
        var action = component.get("c.getQuestions");
        action.setParams({ section : targetId });
        action.setCallback(this,function(response){
            component.set("v.ListQuestions", response.getReturnValue())
        });
        $A.enqueueAction(action);
    },
    
    showSecQuestions : function(component,event,helper){
        
        var sectionId=event.target.id;
        console.log('tok**'+sectionId)
        var token = sectionId.split('--');
        console.log(token);
        var targetId = token[1];
        console.log('targetId'+targetId);
        var divId = 'div--'+targetId;
        var componentTarget = document.getElementById(divId);
        if(document.getElementById(event.target.id).value == "-") {
            document.getElementById(event.target.id).value = "+";
        }else {
            document.getElementById(event.target.id).value = "-";
        }
       
       /* var targetId = event.target.id;
        
        var divId = 'div__'+targetId;
        console.log('in section toggle'+divId);
        var componentTarget = document.getElementById(divId);*/
        $A.util.toggleClass(componentTarget,'toggleshow');
        
        var sections = component.get("v.ListSections");
        for (var sIndex in sections) {
            if(sections[sIndex].Id == targetId){
                var questionsList = sections[sIndex].InspectionReportResponse__r;
                for (qIndex in questionsList) {
                    var eachQuestion = questionsList[qIndex];
                    var divTarget = document.getElementById('div__'+eachQuestion.Id);
                    $A.util.removeClass(divTarget,'toggleshow');
                }
            }
        }
    },
    
     SaveResponse : function(component, event, helper){
	 var submitcheck = false;
          //helper.SaveResponseHelper(component);
           // Update Inspection Comments start 
         var inspectincomments = component.get("v.headeRecord");
        // if(inspectincomments[0].Inspection_Comments__c!=''){
			helper.SaveInspectionComments(component,false);
		 //}
		// else
		//	helper.SaveResponseHelper(component,false);
		  // Update Inspection Comments end 
       
       },   
    
     onSelect: function(component, event, helper) {
   
        var element = event.getSource();
        var id=  element.get("v.text");
        console.log('NEW**'+id);
        var findings = component.get("v.ehsFinidngs");
		 component.set("v.errorRequiredFlag",false);
	     component.set("v.errorMsgDetails",'');
		// component.set("v.rowErrorIndex",0);
		 
        var tokens = id.split('_');  
        console.log(tokens);
         var sections = component.get("v.ListSections");
         if (tokens[0] =='NO') {
             var componentElement = document.getElementById('div__'+tokens[1]);
             component.set("v.ehsFinidngs",findings);
             $A.util.removeClass(componentElement,'toggleshow');
         } else {
             var componentElement = document.getElementById('div__'+tokens[1]);
             $A.util.addClass(componentElement,'toggleshow');
			
         }
       
     
        console.log('the element'+element.get("v.value"));
        if(element.get("v.value")){
            console.log(component.get("v.selectedOptions").indexOf(id));
            var data = component.get("v.selectedOptions");
            if((data.indexOf('YES_'+tokens[1])<0) && ((data.indexOf('NO_'+tokens[1])<0)) &&((data.indexOf('NA_'+tokens[1])<0))){
                data.push(id); 
            }else {
                if(data.indexOf('YES_'+tokens[1])>=0){
                    data.splice(data.indexOf('YES_'+tokens[1]),1);
                      
                }else if(data.indexOf('NO_'+tokens[1])>=0) {
                    data.splice(data.indexOf('NO_'+tokens[1]),1);
                     
                }else if(data.indexOf('NA_'+tokens[1])>=0){
                    data.splice(data.indexOf('NA_'+tokens[1]),1);
                      
                }
                data.push(id);
            }
            component.set("v.selectedOptions",data);
            }
            
         var action1= component.get("c.saveInspectionFindings");
         action1.setParams({
             "responseId" : tokens[1],
             "response" : tokens[0],
             "ehsSequence" :1
             
         });
         action1.setCallback(this,function(response){
             console.log('action1****'+response.getReturnValue());
             component.set("v.ehsId",response.getReturnValue());
             console.log(response.getState()) ;
             var sections = component.get("v.ListSections");
             if(response.getState() == 'SUCCESS'){
                 component.set("v.EHSSequnece",1);
                 for(var index in sections) {
                     var totalQuestions=0;
                     var answeredQuestions=0;
                     var status =0;
                     var questions = sections[index].InspectionReportResponse__r;
                     for(var qIndex in questions){
                         totalQuestions++;
                         if(questions[qIndex].Id ==tokens[1]){
                             
                             questions[qIndex].InspectionResponse__c=tokens[0];
                             if (tokens[0] =='NO') {
                                 var oldFindings =  questions[qIndex].InspectionFindings__r;
                                 if(oldFindings.length !=0){
                                     questions[qIndex].InspectionFindings__r= [];
                                 }
                                 questions[qIndex].InspectionFindings__r.push({'sobjectType' : 'MTX_InspectionFinding__c',
                                                                               'Id'     : component.get("v.ehsId"),
                                                                               'ActionDescription__c' : '' ,
                                                                               'FindingDescription__c' : '',
                                                                               'HeaderId__c': component.get("v.recordId"),
                                                                               'InspectionReportResponse__c' :tokens[1]
                                                                               
                                                                              });
								
                                                                             
                             }
                         }
                         if((questions[qIndex].InspectionResponse__c != '') && 
                            (questions[qIndex].InspectionResponse__c != null)){
                             answeredQuestions++;
                         }
                         
                     }
                     
                     status = status+(answeredQuestions*100)/totalQuestions;
                     document.getElementById('progress_'+sections[index].Id).firstChild.innerHTML = Math.round(status)+'%'
                     document.getElementById('progress_'+sections[index].Id).style.width = Math.round(status)+'%';
                 }  
                 
                 
             }
             component.set("v.ListSections",sections);
         });
         
         console.log(component.get("v.ListSections"));
         $A.enqueueAction(action1);  
         
     },
    

    
    addRow : function(component, event){
        var id =event.target.id;
        console.log('id*****'+id);
        var tokens=id.split('__');
        console.log('index in add row **'+tokens[2]);
        var findings=component.get("v.ehsFinidngs");
        var sections = component.get("v.ListSections");
        var action = component.get("c.getFindingsSequence");
        action.setParams({
            "responseId" : tokens[1]
        }); 
        
        action.setCallback(this,function(response){
            var sequenceNo = 0;
            console.log('action****'+response.getReturnValue());
            if(response.getState() == 'SUCCESS'){
                sequenceNo = response.getReturnValue();
              
            }
            var action1= component.get("c.saveInspectionFindings");
            action1.setParams({
                "responseId" : tokens[1],
                "response" : 'NO',
                "ehsSequence" : (parseInt(sequenceNo)+1)
                
            });
            action1.setCallback(this,function(response){
                console.log('action1****'+response.getReturnValue());
                component.set("v.ehsId",response.getReturnValue());
                console.log(response.getState()) ;
                var sections = component.get("v.ListSections");
                if(response.getState() == 'SUCCESS'){
                    for(var sIndex in sections) {
                        
                        var questions = sections[sIndex].InspectionReportResponse__r;
                        
                        for(var qindex in questions) {
                            var eachQuestion = questions[qindex];
                            if(eachQuestion.Id == tokens[1]){
                                var findingsSize = eachQuestion.InspectionFindings__r.length;
                                console.log('findingsSize'+findingsSize);
                                eachQuestion.InspectionFindings__r.push({'sobjectType' : 'MTX_InspectionFinding__c',
                                                                         'Id'     : response.getReturnValue(),
                                                                         'ActionDescription__c' : '' ,
                                                                         'FindingDescription__c' : '',
                                                                         'HeaderId__c': component.get("v.recordId"),
                                                                         'InspectionReportResponse__c' :tokens[1]
                                                                        
                                                                         
                                                                        }
                                                                       );
                            }
                        }
                    }
                    
                    component.set("v.ListSections", sections);
                    component.set("v.ehsFinidngs",findings);
                    
                }
            });
            $A.enqueueAction(action1);  
        });
        $A.enqueueAction(action);  
    },
    
    
    removeRow : function(component, event, helper) {
        var spanId = event.target.id;
        console.log('spanId*******'+spanId);
        var bodySpan = document.getElementById(spanId).firstChild;
        console.log(bodySpan);
        //var domEvent = event.getParams().domEvent;
        // var bodySpan = domEvent.target.nextSibling;
        //console.log(bodySpan.id);
        //var spanId = bodySpan.id;
        var tokens = spanId.split('--');
        var index = bodySpan.dataset.index;
        console.log('index'+index);
        var deleteFinding = [];
        var sections = component.get("v.ListSections");
        for (var sIndex in sections) {
            var questions = sections[sIndex].InspectionReportResponse__r;
            for (var qIndex in questions) {
                if (tokens[1] == questions[qIndex].Id){
                    var findings = questions[qIndex].InspectionFindings__r;
                    deleteFinding.push(findings[index]);
                    findings.splice(index,1);
                    console.log('in delete findings before splicing');
                    questions[qIndex].InspectionFindings__r = findings;
                    console.log(questions[qIndex].InspectionFindings__r);
                    
                }
            }
            
        }
        component.set("v.deleteinspectionFindings",deleteFinding);
        var action = component.get("c.deleteFindings");
        action.setParams({ 
            deletableFindings : component.get("v.deleteinspectionFindings")
        });
        action.setCallback(this,function(response){
            console.log(response.getReturnValue());        
        });
        component.set("v.ListSections",sections);
        component.set("v.ehsFinidngs",findings);
        $A.enqueueAction(action);
        
        
    },
    
    saveImage : function(component, event, helper){
        var id=event.target.id;
        console.log(id);
        debugger;
        tokens = id.split('--');
        fileId = 'file--'+tokens[1];
        var totalImageCount =0;
        if (component.get("v.ImageParentId").indexOf(tokens[1]) < 0) { 
            component.get("v.ImageParentId").push(tokens[1]); 
        } 
        
        var fileInput = document.getElementById(fileId);
        console.log(fileInput.files.length);
        var imagecount = fileInput.files.length;
        for(var i=0; i<fileInput.files.length; i++)  { 
            console.log('i'+i)
            var file = fileInput.files[i];
            console.log('file format');
            console.log(fileInput.files[i]);
            //var output = document.getElementById('showI');
            //output.src = URL.createObjectURL(file);
            helper.save(component,file);
        }
        
    },    
    showGuidanceNote : function(component,event,helper){
        var targetId=event.target.id;
        console.log(targetId);
        var getId = targetId.split('_');
        var divId =getId[1];
        var componentTarget = document.getElementById(divId);
        $A.util.toggleClass(componentTarget,'toggleshow');
        
    },
    
    submitForm : function(component,event,helper){
        var submitcheck = false;
          //helper.SaveResponseHelper(component);
           // Update Inspection Comments start 
         var inspectincomments = component.get("v.headeRecord");
         if(inspectincomments[0].Inspection_Comments__c!=''){
			helper.SaveInspectionComments(component,true);
		 }
		 else
			helper.SaveResponseHelper(component,true);
		  // Update Inspection Comments end 
		//helper.formSubmitAction(component);
    },
    
    Cancel : function(component, event){
        //sforce.one.back(true);   
        var recordId = component.get("v.headeRecord"); 
       
       
        var action= component.get("c.cancelResponse");
        action.setParams({ inspection :recordId});
        action.setCallback(this,function(response){
            console.log('State ----> '+ response.getState());
            
            if(component.isValid() && response.getState() === "SUCCESS") {
                 sforce.one.back(true);
            }else if (response.getState == "ERROR") {
                console.log('Problem saving , response state: ' + response.getState());
            }
            
        });
        $A.enqueueAction(action);
    },
    
    popupImage : function(component, event, helper){
        helper.popupImageHelper(component);
    },
    
    
    
    showModal : function(component, event, helper){
        console.log('in showModal');
        helper.showModalHelper(component);
        
    },
    closeImagePopup : function(component, event, helper){
        modalIdvalue = event.target.id;
        console.log('in showModal'+modalIdvalue);
        var modalId = modalIdvalue.split('--');
        console.log("in closeImagePopup");
        //var popup = component.find("modal");
        var popup = document.getElementById('modal--'+modalId[1]);
        $A.util.toggleClass(popup,"slds-show");
        $A.util.toggleClass(popup,"slds-hide");
        
    },
    
    selectCheckbox :  function(component, event, helper){
        helper.selectCheckboxHelper(component);
    },
    
    
    deleteImagesofFindings :  function(component, event, helper){
        console.log('in delete');
        helper.deleteImagesHelper(component);
        
    },
	 // this function automatic call by aura:waiting event  
    showSpinner: function(component, event, helper) {
       // make Spinner attribute true for display loading spinner 
        component.set("v.Spinner", true); 
   },
    
 // this function automatic call by aura:doneWaiting event 
    hideSpinner : function(component,event,helper){
     // make Spinner attribute to false for hide loading spinner    
       component.set("v.Spinner", false);
    },
})