({    
    showHeaderHelper : function(component) {
        var action = component.get("c.getHeader");
        action.setParams({ headerId : component.get("v.recordId") });
        var that = this;
        action.setCallback(that,function(response){
            component.set("v.headeRecord" ,response.getReturnValue());
            that.showSection(component);
            var status = component.get("v.headeRecord[0].Status__c");
            var frequency = component.get("v.headeRecord[0].InspectionReportFrequency__c");
            var numberOfDaysToAdd = 6;
            //calculation of date
            var dueDate = component.get("v.headeRecord[0].InspectionReportDueDate__c");
            var dueDateadd = new Date(dueDate);
            console.log(dueDateadd+'****dueDateadd');
            dueDateadd.setDate(dueDateadd.getDate() + numberOfDaysToAdd); 
            console.log(dueDateadd+'dueDateadd');
            var dueDates = dueDate.split('-');
            var duedateFormat = dueDates[2]+'/'+dueDates[1]+'/'+dueDates[0];
            console.log('duedateFormat'+duedateFormat);
            var today = new Date();
            console.log(today+'today');
            var curr_month = today.getMonth()+1;
            console.log(curr_month);
            console.log('frequency*****'+frequency);
            console.log('status*****'+status);
            if(((dueDateadd < today) && (frequency ===  "Weekly") 
                && (status !== "Completed") && (status !== "Missed")) 
               ||(((frequency === "Monthly")
                   || (frequency === "Quarterly") 
                   || (frequency === "6 Monthly") 
                   || (frequency === "Annually")
                   || (frequency === "Once Only")) 
                  && (status !== "Completed") 
                  && (dueDates[1] < curr_month))){
                console.log("LOCK");
                var savebtn = component.find("save");
                console.log('savebtn>>>'+savebtn);
                $A.util.toggleClass(savebtn, 'btn');
                $A.util.toggleClass(savebtn, 'btndisabled');
                var savedisable = component.find("save").getElement();
                console.log(savedisable);
                savedisable.setAttribute("disabled","true");
                var submitbtn = component.find("submit");
                console.log('submitbtn>>>'+submitbtn);
                $A.util.toggleClass(submitbtn, 'btn');
                $A.util.toggleClass(submitbtn, 'btndisabled');
                var st = component.find("submit").getElement();
                console.log(st);
                st.setAttribute("disabled","true");
                component.set("v.formSubmit", "true");
                //component.set("v.submitValue", "true"); 
            }
            if((dueDateadd >= today)){
                console.log('in new loop'); 
            }
            if(((status != "Completed") && (status !=  'Missed')) 
               && (((dueDateadd >= today) && (frequency === "Weekly"))
                   || ((dueDates[1] >= curr_month)
                       && (((frequency === "Monthly")
                            || (frequency === "Quarterly")
                            || (frequency === "6 Monthly")
                            || (frequency === "Annually")
                            || (frequency === "Once Only")))))){
                var submitbtn = component.find("submit");
                
                console.log('in second if');
                console.log('submitbtn>>>'+submitbtn);
                $A.util.toggleClass(submitbtn, 'btn');
                $A.util.toggleClass(submitbtn, 'btndisabled');
                var st = component.find("submit").getElement();
                console.log(st);
                st.setAttribute("disabled","true");
                //component.set("v.submitValue",false);
            }           
            if(status == "Completed"){
                
                var savebtn = component.find("save");
                console.log('savebtn>>>'+savebtn);
                $A.util.toggleClass(savebtn, 'btn');
                $A.util.toggleClass(savebtn, 'btndisabled');
                var savedisable = component.find("save").getElement();
                console.log(savedisable);
                savedisable.setAttribute("disabled","true");
                var submitbtn = component.find("submit");
                console.log('submitbtn>>>'+submitbtn);
                $A.util.toggleClass(submitbtn, 'btn');
                $A.util.toggleClass(submitbtn, 'btndisabled');
                var st = component.find("submit").getElement();
                console.log(st);
                st.setAttribute("disabled","true");
                component.set("v.formSubmit", "true");
                //component.set("v.submitValue", "true");
            }
            if(status == "Missed"){
                
                var savebtn = component.find("save");
                console.log('savebtn>>>'+savebtn);
                $A.util.toggleClass(savebtn, 'btn');
                $A.util.toggleClass(savebtn, 'btndisabled');
                var savedisable = component.find("save").getElement();
                console.log(savedisable);
                savedisable.setAttribute("disabled","true");
                var submitbtn = component.find("submit");
                console.log('submitbtn>>>'+submitbtn);
                $A.util.toggleClass(submitbtn, 'btn');
                $A.util.toggleClass(submitbtn, 'btndisabled');
                var st = component.find("submit").getElement();
                console.log(st);
                st.setAttribute("disabled","true");
                component.set("v.formSubmit", "true");
                //component.set("v.submitValue", "true");
            }
			this.refreshFindings(component);
        });
        $A.enqueueAction(action); 
    },
	/* Delete unwantedFindings for Yes radio button while page refresh start  */
		
	 refreshFindings :  function(component, event) {
		var recordId = component.get("v.headeRecord"); 
       
       
        var action= component.get("c.cancelResponse");
        action.setParams({ inspection :recordId});
        action.setCallback(this,function(response){
            console.log('State ----> '+ response.getState());
            
           if (response.getState == "ERROR") {
                console.log('Problem saving , response state: ' + response.getState());
            }
            
        });
        $A.enqueueAction(action);
	
	},
	
	/* Delete unwantedFindings for Yes radio button while page refresh End  */

    showSection :  function(component, event) {
        var action = component.get("c.getSections");
        action.setParams({ headerName : component.get("v.headeRecord[0].Id")});
        var that = this;
        action.setCallback(this,function(response){
            var sections = response.getReturnValue();
            component.set("v.ListSections", sections);
            //document.getElementsByTagName("header").style= "display:none";            
            that.showQuestions(component);
            that.showPercentage(component);
            setTimeout(function(){ that.showCount(component); }, 2000);
        });
        $A.enqueueAction(action); 
        
    },
    
    showQuestions : function(component){
        
        console.log('in showQuestions');
        var action = component.get("c.getQuestionswithAnswers");
        var fieldName = component.get("v.sampleEhsFinidng");
        
        action.setParams({ sections : component.get("v.ListSections"), 
                           headerId : component.get("v.recordId")});
        action.setCallback(this,function(response){
            console.log('in setCallback2');
            var questions = response.getReturnValue();
            var retainValue = component.get("v.retainSection");
            console.log('questions');
            console.log(questions);
            var sections = component.get("v.ListSections");
            var findings = component.get("v.ehsFinidngs");
            var efindingsMap={};
            //var totalQuestions=0;
            for(var index in sections) {
                var totalQuestions=0;
                var answeredQuestions=0;
                var sectionId = sections[index].Id;
                if (questions[sectionId] != null){
                    var questionsList = questions[sectionId];
                    sections[index].InspectionReportResponse__r = questions[sectionId];
                    for (var qIndex in questionsList){
                        totalQuestions++;
                        var eachQuestion = questionsList[qIndex];
                        console.log(eachQuestion.InspectionResponse__c);
                        if((eachQuestion.InspectionResponse__c != null) &&
                           (eachQuestion.InspectionResponse__c != '')){
                            answeredQuestions++;
                            if(retainValue.indexOf(sections[index].Id)<0){
                                retainValue.push(sections[index].Id);
                            }
                        }
                        if(eachQuestion.hasOwnProperty('InspectionFindings__r')){
                            var findingsList = eachQuestion.InspectionFindings__r;
                            console.log(eachQuestion);
                            efindingsMap[eachQuestion.Id]=eachQuestion.InspectionFindings__r;
                            console.log('findings');
                            
                            console.log(efindingsMap);
                            console.log('test');
                            console.log(findingsList);
                            for(fIndex in findingsList){
                                var eachfind = findingsList[fIndex];
                                findings.push(eachfind);
                            }
                        }else {
                            eachQuestion.InspectionFindings__r=[];
                        }
                    }
                }
                
                var statusbar = ((answeredQuestions*100)/totalQuestions);
                var statuslist = component.get("v.statusList");
                var secStatus = statusbar+'__'+sectionId;
                statuslist.push(secStatus);
                component.set("v.statusList",statuslist);
                
                document.getElementById('progress_'+sectionId).firstChild.innerHTML = Math.round(statusbar)+'%';
                //document.getElementById('percent_'+sectionId).innerHTML = Math.round(statusbar)+'%';
                document.getElementById('progress_'+sectionId).style.width = Math.round(statusbar)+'%';
            }
            
            
            console.log('retainValue');
            for(var retain in retainValue){
                showsectionId = 'div--'+retainValue[retain];
                var sectionTarget = document.getElementById(showsectionId);
                var sectionBlock = 'sect--'+retainValue[retain];
                document.getElementById(sectionBlock).value = "-";
                $A.util.toggleClass(sectionTarget,'toggleshow');
                
                for (var sIndex in sections) {
                    if(sections[sIndex].Id == retainValue[retain]){
                        console.log('sections[sIndex].Id***'+sections[sIndex].Id);
                        console.log('retain vaue****'+retainValue[retain]);
                        var questionsList = sections[sIndex].InspectionReportResponse__r;
                        
                        for (qIndex in questionsList) {
                            var eachQuestion = questionsList[qIndex];
                            var divTarget = document.getElementById('div__'+eachQuestion.Id);
                            console.log('in div ID'+'div__'+eachQuestion.Id);
                            $A.util.toggleClass(divTarget,'toggleshow');
                        }
                    }
                }
            }
            console.log(retainValue);
            component.set("v.ehsFinidngs",findings);
            component.set("v.ListSections" ,sections);
            component.set("v.findingsMap",efindingsMap );
            console.log('findings');
            console.log(efindingsMap);
            
            
        });
        $A.enqueueAction(action);
    },
    SaveResponseHelper : function(component,submitCheck){
        //alert(component.get("v.rowErrorIndex"));
		//alert('@@submitCheck@@'+submitCheck);
	
        var seclist = component.get("v.ListSections");
        console.log(seclist);
        //var findings = component.get("v.ehsFinidngs");
        var responseList = [];
        var findingsList=[];
		var noRadioCheck = false;
        
        for (var index in seclist) {
            var questions = seclist[index].InspectionReportResponse__r;
			//alert('@@@questions@@@'+questions);
            var responses ;            
            responses = questions;
			
            for(var rIndex in responses){
                var eachresponse = responses[rIndex];
				//alert('@@@eachresponse@@'+eachresponse.InspectionResponse__c);
				
				responseList.push(eachresponse);           
            }
			
            for (var qindex in questions){
                ///responses = questions[qindex];

                var findings = questions[qindex].InspectionFindings__r;
                for(var fIndex in findings){
                    var eachFind = findings[fIndex];
					
					
                   // findingsList.push(eachFind);
					//component.set("v.errorRequiredFlag",false);
					//component.set("v.errorMsgDetails",'');
                }
                console.log(findingsList);
                /*for(var rIndex in responses){
                    var eachresponse = responses[rIndex];
                    responseList.push(eachresponse);
                }*/
            }
			for(var rIndex in responses){
                var eachresponse = responses[rIndex];
				//alert('@@@eachresponse@@'+eachresponse.InspectionResponse__c);
				var findings = responses[rIndex].InspectionFindings__r;
				//responseList.push(eachresponse);
				 for(var fIndex in findings){
                    var eachFind = findings[fIndex];
					//alert('@@@eachFind@@'+eachFind.InspectionResponse__c);
					if((eachFind.FindingDescription__c == undefined || eachFind.FindingDescription__c == '') && eachresponse.InspectionResponse__c=='NO'){
						component.set("v.errorRequiredFlag",true);
						alert('The "Finding Description" and "Corrective action" are mandatory when "No" is selected for a question');
						component.set("v.errorMsgDetails","Finding Description is mandatory for the Question"+questions[qindex].Sequence__c);
						//component.set("v.rowErrorIndex",questions[qindex].Sequence__c);
						//alert('@@finddesc@@'+eachFind.FindingDescription__c+'@@index@@'+eachFind.InspectionReportResponse__c);
						//alert('@@Sequence__c@@'+questions[qindex].Sequence__c);
						return;
					}
					if((eachFind.ActionDescription__c == undefined || eachFind.ActionDescription__c == '')&& eachresponse.InspectionResponse__c=='NO'){
						component.set("v.errorRequiredFlag",true);
						component.set("v.errorMsgDetails","Corrective Action is mandatory for the Question"+questions[qindex].Sequence__c);
						alert('The "Finding Description" and "Corrective action" are mandatory when "No" is selected for a question');
						//component.set("v.rowErrorIndex",questions[qindex].Sequence__c);
						//alert('@@@@actiondesc@@@'+eachFind.ActionDescription__c+'@@index@@'+eachFind.InspectionReportResponse__c);
						//alert('@@Sequence__c@@'+questions[qindex].Sequence__c);
						return;
					}
					findingsList.push(eachFind);
					}
					component.set("v.errorRequiredFlag",false);
					component.set("v.errorMsgDetails",'');
				
                
            }
        }
        console.log('all findings');
        console.log(findingsList);
        
        console.log('all responses');
        console.log(responseList);
        var action= component.get("c.saveResponses");
        action.setParams({ responses :responseList, findings : findingsList});
        action.setCallback(this,function(response){
            var ratio= response.getReturnValue();
            console.log('ratio'+ratio);
            component.set("v.answerRatio",ratio);
            console.log('State ----> '+ response.getState());
            
            if(component.isValid() && response.getState() === "SUCCESS") {
			if(submitCheck==true){
			this.formSubmitAction(component);
			}
                else{
				var resultsToast = $A.get("e.force:showToast");
                if(!resultsToast){
                    
                    console.log('in toast '+document.getElementById("toastmessage").innerHTML)
                    document.getElementById("toastmessage").innerHTML = "Inspection Saved Sucessfully";
                    window.location.reload();
                    //window.close();
                    return;
                }
                resultsToast.setParams({
                    "title": "Inspection Saved",
                    "message": "The new Inspection was created."
                });
                //$A.get("e.force:closeQuickAction").fire();
                resultsToast.fire();
                $A.get("e.force:refreshView").fire();
                }
                
            }else if (response.getState == "ERROR") {
                console.log('Problem saving , response state: ' + response.getState());
            }
            
        });
        $A.enqueueAction(action);
    },
    
    
    showPercentage : function(component, event,callback){
        var action= component.get("c.getPercentage");
        action.setParams({
            "headerId" : component.get("v.recordId")
        });
        action.setCallback(this,function(response){
            var displayValue = response.getReturnValue();
            var status = component.get("v.headeRecord[0].Status__c");
            var display = displayValue.split('_');
            component.set("v.totalpercent" ,display[0]);
            component.set("v.answerRatio",display[1]);
            console.log(display[1]+'display[1]');
            var complianceValue = display[1];
            var sections = component.get("v.ListSections");
            
            var sizeList =[];
            for(var y in sections){
                console.log(sizeList);
                for(var z in sections[y].InspectionReportResponse__r){
                    sizeList.push(sections[y].InspectionReportResponse__r[z]);
                    
                }
            }
            console.log(sizeList.length);
            if(complianceValue == '0'){
                complianceValue = '0/'+sizeList.length;
            }
            console.log(complianceValue+'after complianceValue');
            component.set("v.answerRatio",complianceValue);
            
            var complianceKPI = display[0];
            console.log(complianceKPI);
            var token = display[1];
            var tokenvalue = token.split('/');
            var submitbtn = component.find("submit");
            console.log('submitbtn n percentage'+submitbtn);
            if(tokenvalue[0] == tokenvalue[1] && status != 'Completed')
            {	
                var st = component.find("submit").getElement();
                console.log(st);
                st.removeAttribute("disabled");
                component.set("v.submitValue",false);
                var submitbtn = component.find("submit");
                console.log('submitbtn>>>'+submitbtn);
                $A.util.toggleClass(submitbtn, 'btn');
                $A.util.toggleClass(submitbtn, 'btndisabled');
                
            }
            
            console.log('totalpercent.showPercent .'+response.getReturnValue());
            if(complianceKPI >=0 && complianceKPI < 75){
                document.getElementById('percentage').className= 'percentred';
                
            }
            if(complianceKPI >75 && complianceKPI<95){
                document.getElementById('percentage').className= 'percentamber';
                
            }
            if(complianceKPI >94 && complianceKPI<=100){
                document.getElementById('percentage').className= 'percentgreen';
            }
        });
        $A.enqueueAction(action); 
        
    },
    
    
    
    save : function(component,file) {
        /*  var id=event.target.id;
        console.log(id);
        tokens = id.split('--');
        fileId = 'file--'+tokens[1];
        console.log(fileId);
         var fileInput = document.getElementById(fileId);
       console.log(fileInput.files.length);
       debugger;
       for(var i=0; i<fileInput.files.length; i++)  { 
             console.log('i'+i)
            var file = fileInput.files[i];
             console.log(fileInput.files[i]);*/
       console.log('in helper file');  
        console.log('in helper file'+tokens[1]);  
       console.log(file);
       var MAX_FILE_SIZE = 4500000;
       var CHUNK_SIZE = 500000;
       if (file.size > MAX_FILE_SIZE) {
           alert('File size cannot exceed ' + MAX_FILE_SIZE + ' bytes.\n' +
                 'Selected file size: ' + file.size);
           return;
       }        
       var fileread  = new FileReader();
       var self = this;
       fileread .onload = $A.getCallback(function() {
           var fileContents = fileread .result;
           var base64Mark = 'base64,';
           var dataStart = fileContents.indexOf(base64Mark) + base64Mark.length;
           fileContents = fileContents.substring(dataStart);
           console.log('Total file size: ' + file.size + 'MB base64Mark: ' + fileContents.length);
           upload(component, file, fileContents, CHUNK_SIZE);
       });
       fileread .readAsDataURL(file);
       
       var upload = function(component, file, fileContents, CHUNK_SIZE) {
           var fromPos = 0;
           var toPos = Math.min(fileContents.length, fromPos + CHUNK_SIZE);
           console.log('Upload first chunk from: 0 to : ' + toPos);
           uploadChunk(component, file, fileContents, CHUNK_SIZE, fromPos, toPos, '');   
       }
       
       var uploadChunk = function(component, file, fileContents, CHUNK_SIZE, fromPos, toPos, attachId) {
	            var action = component.get("c.saveTheChunk"); 
           var chunk = fileContents.substring(fromPos, toPos);
           action.setParams({
               parentId: tokens[1],
               fileName: file.name,
               base64Data: encodeURIComponent(chunk), 
               contentType: file.type,
               fileId: attachId
           });
           var self = this;
           action.setCallback(this, function(a) {
               ImageValue = a.getReturnValue();
               tokensImagevalue = ImageValue.split('--');
               attachId = tokensImagevalue[0];
			   attachId = ImageValue;
               fromPos = toPos;

               toPos = Math.min(fileContents.length, fromPos + CHUNK_SIZE);
               if (fromPos < toPos ) {
                   console.log('Upload again chunk from: ' + fromPos + ' to: ' + toPos);
                   uploadChunk(component, file, fileContents, CHUNK_SIZE, fromPos, toPos, attachId);  
               }
               else {
                   if (attachId !== null){
                       alert('Image Saved Sucessfully');
                       
                       var countforFindings = component.get("v.imageCountMap");
                       if(countforFindings !== null && countforFindings[tokens[1]] !== undefined){
                           totalImageCount = 1+countforFindings[tokens[1]];
                       }else{
                           totalImageCount = 1;
                       }
                       var countMap = {};
                       countMap[tokens[1]] = totalImageCount;
                       console.log(countMap);
                       component.set("v.imageCountMap",countMap);
                       console.log(component.get("v.ImageParentId"));
                       
                       // var selectedImageList = component.get("v.selectedImages");
                       
                       var totalImageCount1 = component.get("v.imageCount");
                       
                       console.log('totalImageCount'+totalImageCount);
                       console.log('after adding totalImageCount'+totalImageCount);
                       var findingid = 'count--'+tokens[1];
                       console.log(findingid);
                       document.getElementById(findingid).innerHTML = totalImageCount;
                   }else{
                       
                   }
                   console.log('Attachment done Id: ' + attachId);
               }
           });
           $A.enqueueAction(action); 
       }
       
       } ,
    
    showCount : function(component, event,callback){
        var findingitems = component.get("v.ehsFinidngs");
        console.log('findingitems');
        var countMap = {};
        console.log(findingitems);
        for(var x in findingitems){
            var findingsId = findingitems[x].Id;
            console.log('findingsId'+findingsId);
            var imgcount = findingitems[x].ImageCount__c;
            if(!imgcount){
                imgcount = 0;
            }else{
                console.log('imgcount---'+imgcount);
                var findingid = 'count--'+findingsId;
                console.log('------->@'+findingid+'@');
                document.getElementById(findingid).innerHTML = imgcount;
                //component.set("v.ImageNo",imgcount);
                countMap[findingsId] = imgcount;
                console.log(countMap);
                 component.set("v.imageCountMap",countMap);
                component.set("v.imageCount",imgcount);
                console.log(component.get("v.imageCountMap"));
            }
        }
        
        
    },
    
    popupImageHelper : function(component){
        console.log('popupImage');
        var id=event.target.id;
        var that = this;
        console.log(id);
        tokens = id.split('--');
        fileId = 'file--'+tokens[1];
        console.log(fileId);
        var output = document.getElementById('Imgshow--'+tokens[1]);
        output.innerHTML = "";
        var fileInput = document.getElementById(fileId);
        console.log(fileInput.files.length);
        var imagecount = fileInput.files.length;
        component.set("v.imageCount",imagecount);
        for(var i=0; i<fileInput.files.length; i++)  { 
            console.log('i'+i)
            var file = fileInput.files[i];
            console.log('file format');
            console.log(fileInput.files[i]);
            //output.src = URL.createObjectURL(file);
              if (typeof (FileReader) != "undefined") {
                   var regex = /^([a-zA-Z0-9\s_\\.\-:])+(.jpg|.jpeg|.gif|.png|.bmp)$/; 
                  if (regex.test(file.name.toLowerCase())) {
                      var reader = new FileReader();
                      var newdiv = document.createElement('div');
                      newdiv.className = "popimgdiv";
                      var divIdName = 'mydiv--'+tokens[1]+'--'+i;
                      newdiv.setAttribute('id',divIdName);
                      var checkbox = document.createElement('input');
                      checkbox.type = 'checkbox';
                      //cbs = '<input type="checkbox" onchange="{!v.selectCheckbox}" value="Select" />';
                      newdiv.appendChild(checkbox);
                      //newdiv.innerHTML = cbs;
                      checkbox.name = 'val';
                      checkbox.value = '';
                      var checkboxId = 'sel--'+tokens[1]+'--'+i;
                      checkbox.setAttribute('id',checkboxId);
                      checkbox.onclick = function(){
                          alert('in inside');
                          that.selectCheckboxHelper(component);
                      };
                      	//cb.onclick = component.getReference("c.selectCheckbox");
                      	//cb.setAttribue('onclick','selectCheckbox()');
                      var img = document.createElement("IMG");
                      img.height = "100";
                      img.width = "100";
                      img.src = URL.createObjectURL(file);
                      newdiv.appendChild(img);
                      output.appendChild(newdiv);
                      console.log(img);
                      reader.readAsDataURL(file);
                      console.log('output');
                      console.log(output);
                  } else {
                      alert(file.name + " is not a valid image file.");
                      output.innerHTML = "";
                      return false;
                  }
              }
             component.get("v.ImageParentId").push(tokens[1]);
          }
        
        console.log(component.get("v.ImageParentId"));
         var action = component.get("c.getImages");
        action.setParams({ 
            parentIds : component.get("v.ImageParentId")
        });
        action.setCallback(this,function(response){
            
        });
          $A.enqueueAction(action);
     },
    
    selectCheckboxHelper :  function(component){
        console.log('in helper');
        var checkedIdtokens = event.target.id;
        checkedId = checkedIdtokens.split('--');
        console.log(checkedId);
        selectedImageId = checkedId[2];
        if( document.getElementById(checkedIdtokens).checked){
            console.log('in checked'+selectedImageId);
            if (component.get("v.selectedImages").indexOf(selectedImageId) < 0) { 
                component.get("v.selectedImages").push(selectedImageId); 
            } 
            console.log('List of selected Image Ids');
            console.log(component.get("v.selectedImages")); 
        } else { 
            var index = component.get("v.selectedImages").indexOf(selectedImageId); 
            if (index > -1) { 
                component.get("v.selectedImages").splice(index, 1); 
            } 
            console.log('List of selected Image Ids after removing the unchecked images');
            console.log(component.get("v.selectedImages")); 
        }
    },
    
    deleteImagesHelper : function(component){
        console.log('in Helper Delete');
        var id=event.target.id;
        var that = this;
        deleteId = id.split('--');
        console.log('deleteId'+deleteId);
        var findingrecordId = deleteId[1];
        console.log('findingrecordId'+findingrecordId);
        console.log(component.get("v.selectedImages").length);
        if(component.get("v.selectedImages").length == 0){
            alert('Please select the file to delete');
        }
        var action = component.get("c.deleteImages");
        action.setParams({ 
            imagesIdsList : component.get("v.selectedImages"),
            parentIdvalue : findingrecordId
        });
        action.setCallback(this,function(response){
            if(component.isValid() && response.getState() === "SUCCESS"){
                alert('Selected File Deleted');
                console.log('response from delete Images');
                console.log(response.getReturnValue());
                var Icount = response.getReturnValue();
                component.set("v.imageCount",Icount);
                console.log('parent ID before calling get images in delete method'+deleteId[1]);
                var findingid = 'count--'+findingrecordId;
                console.log('------->@'+findingid+'@');
                document.getElementById(findingid).innerHTML = Icount;
                var action1 = component.get("c.getImages");
                action1.setParams({
                    parentId : deleteId[1]
                });
                action1.setCallback(this,function(response){
                    if(component.isValid() && response.getState() === "SUCCESS"){
                        component.set("v.ImageIds",response.getReturnValue());
                        console.log('response from get Images');
                        console.log(response.getReturnValue());
                    }
                });
                $A.enqueueAction(action1);
                    
            }
        });
         $A.enqueueAction(action);
    },
    
    showModalHelper : function(component){
        modalIdvalue = event.target.id;
        console.log('in showModal'+modalIdvalue);
        var modalId = modalIdvalue.split('--');
        var modalElement = document.getElementById('modal--'+modalId[1]);
        var action = component.get("c.getImages");
        action.setParams({ 
            parentId : modalId[1] 
        });
        action.setCallback(this,function(response){
            if(component.isValid() && response.getState() === "SUCCESS"){
                component.set("v.ImageIds",response.getReturnValue());
                console.log('response from get Images');
                console.log(response.getReturnValue());
            }
        });
        console.log(modalElement);
        //var popup = component.find("modal");
        $A.util.toggleClass(modalElement,"slds-show");
        $A.util.toggleClass(modalElement,"slds-hide");
        $A.enqueueAction(action);
    },
    /* Update Inspection Comments start */
    SaveInspectionComments : function(component, submitCheck){
		//alert('@@Inside SaveInspectionComments@@@--'+submitCheck);
		var inspectincomments = component.get("v.headeRecord");
		var action= component.get("c.saveInspectComments");
        action.setParams({ inspection: inspectincomments});
        action.setCallback(this,function(response){
			var response= response.getReturnValue();
            this.SaveResponseHelper(component,submitCheck);
            /*if(component.isValid() && response.getState() === "SUCCESS") {
                               
            }else if (response.getState == "ERROR") {
                console.log('Problem saving , response state: ' + response.getState());
            }*/
		
		});
        $A.enqueueAction(action);
	},
     /* Update Inspection Comments end */
	 formSubmitAction : function(component){
		//alert('@@Submit Button Invoke@@');
		 var action = component.get("c.submitInpection");
        action.setParams({ 
            headerId : component.get("v.recordId") 
        });
		//alert('@@record@@'+component.get("v.recordId") );
        action.setCallback(this,function(response){
		
            if(component.isValid() && response.getState() === "SUCCESS"){
                alert('The Inspection is sucessfully submitted') ;
                component.set("v.formSubmit", "true");
                //component.set("v.submitValue", "true"); 
                var submitbtn = component.find("submit");
                console.log('submitbtn>>>'+submitbtn);
                $A.util.toggleClass(submitbtn, 'btn');
                $A.util.toggleClass(submitbtn, 'btndisabled');
                var st = component.find("submit").getElement();
                console.log(st);
                st.setAttribute("disabled","true");
                var cancel= $A.get("e.force:closeQuickAction");
                if(!cancel){
                    window.close();
                    return;
                }
                cancel.fire();
                
            }else if (response.getState() === "ERROR") {
                console.log('Problem Submitting Inspection, response state: ' + response.getState());
            }            
        });
        setTimeout(function(){sforce.one.back(true)},5000);
        $A.enqueueAction(action); 
	 
	 },
})