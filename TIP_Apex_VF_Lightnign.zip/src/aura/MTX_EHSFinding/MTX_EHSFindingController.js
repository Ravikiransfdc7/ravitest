({
	doInit : function(component, event, helper) {
        //debugger;
        var getUpdateClosureDueDate = component.get("c.getUpdateClosureDueDate");
        getUpdateClosureDueDate.setParams({
            "recordId" : component.get("v.recordId")
        });
        
        getUpdateClosureDueDate.setCallback(this, function(a) {
            //debugger;
            if(a.getState() == 'SUCCESS'){
				component.set("v.EhsFinidng",a.getReturnValue());
                //$A.get('e.force:refreshView').fire();
                //var successMessage = $A.get("$Label.c.MTX_FINDING_CLOSED");
            	//component.set("v.infoMessage", successMessage);
            } else if (a.getState() == 'ERROR') {
                var errorMessage = $A.get("$Label.c.MTX_CLOSURE_OUTCOME_ERROR");
            	component.set("v.errorMessage", errorMessage);
            }
        });
        $A.enqueueAction(getUpdateClosureDueDate); 
    },
	saveClosedFindings : function(component, event, helper) {
        var findingobj = component.get("v.EhsFinidng");
         var action1 = component.get("c.saveEhsFindings");
         findingobj.sobjectType = 'MTX_Finding__c';
		 
        action1.setParams({
            "findobj": findingobj,
			"recordId" : component.get("v.recordId")});
        action1.setCallback(this, function(resp) {
            var stateOfAction1 = resp.getState();
            if (stateOfAction1 === "SUCCESS") {
				var successMessage = $A.get("$Label.c.MTX_FINDING_CLOSED");
            	component.set("v.infoMessage", successMessage);
				component.set("v.errorMessage", null);
                $A.get('e.force:refreshView').fire();
				var cancel= $A.get("e.force:closeQuickAction");
                if(!cancel){
                    window.close();
                    return;
                }
                cancel.fire();
				
            } else {
                if (stateOfAction1 === "ERROR") {
                    var errorMessage = $A.get("$Label.c.MTX_CLOSURE_OUTCOME_ERROR");
            	component.set("v.errorMessage", errorMessage);
                }
            }
        });
        $A.enqueueAction(action1); 
    }
	
})