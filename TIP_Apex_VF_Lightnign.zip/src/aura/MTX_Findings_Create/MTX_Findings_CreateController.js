({
	doInit: function(component, event, helper) {
        
		var findCategory = component.get("c.findingCategoryValues");
        findCategory.setCallback(this, function(response) {
            var state = response.getState();
            //alert('state@@'+state);
            if (state === "SUCCESS") {
                component.set("v.globalfcategory", response.getReturnValue());
                //Initialize dropdown with values
                var opts1 = [{
                    "class": "optionClass",
                    selected: "true"
                }];;
                var globalfcategory = component.get("v.globalfcategory");
                for (var i = 0; i < globalfcategory.length; i++) {
                    opts1.push({
                        "class": "optionClass",
                        label: globalfcategory[i],
                        value: globalfcategory[i]
                    });
                }
                component.find("findCategoryId").set("v.options", opts1);
                
            }
        });
        $A.enqueueAction(findCategory); 
		var observationType = component.get("c.opservationTypeValues");
        observationType.setCallback(this, function(response) {
            var state = response.getState();
            //alert('state@@'+state);
            if (state === "SUCCESS") {
                component.set("v.globalOType", response.getReturnValue());
                //Initialize dropdown with values
                var opts1 = [{
                    "class": "optionClass",
                    selected: "true"
                }];;
                var globalOType = component.get("v.globalOType");
                for (var i = 0; i < globalOType.length; i++) {
                    opts1.push({
                        "class": "optionClass",
                        label: globalOType[i],
                        value: globalOType[i]
                    });
                }
                component.find("observationTypeId").set("v.options", opts1);
                
            }
        });
        $A.enqueueAction(observationType); 
		var findingType = component.get("c.findingTypeValues");
        findingType.setCallback(this, function(response) {
            var state = response.getState();
            //alert('state@@'+state);
            if (state === "SUCCESS") {
                component.set("v.globalrFType", response.getReturnValue());
                //Initialize dropdown with values
                var opts1 = [{
                    "class": "optionClass",
                    selected: "true"
                }];;
                var globalrFType = component.get("v.globalrFType");
                for (var i = 0; i < globalrFType.length; i++) {
                    opts1.push({
                        "class": "optionClass",
                        label: globalrFType[i],
                        value: globalrFType[i]
                    });
                }
                component.find("findingTypeId").set("v.options", opts1);
                
            }
        });
        $A.enqueueAction(findingType);
		var findingSource = component.get("c.FindgingSourceVaalues");
        findingSource.setCallback(this, function(response) {
            var state = response.getState();
            //alert('state@@'+state);
            if (state === "SUCCESS") {
                component.set("v.globalrFSource", response.getReturnValue());
                //Initialize dropdown with values
                var opts1 = [{
                    "class": "optionClass",
                    selected: "true"
                }];;
                var globalrFSource = component.get("v.globalrFSource");
                for (var i = 0; i < globalrFSource.length; i++) {
                    opts1.push({
                        "class": "optionClass",
                        label: globalrFSource[i],
                        value: globalrFSource[i]
                    });
                }
                component.find("findingSourceId").set("v.options", opts1);
				component.set("v.EhsFinidng.FindingSource__c","General Observation");
				
                
            }
        });
        $A.enqueueAction(findingSource);

		var closurePriority = component.get("c.closurePriorityValues");
        closurePriority.setCallback(this, function(response) {
            var state = response.getState();
           // alert('state@@'+state);
            if (state === "SUCCESS") {
                component.set("v.globalrClosurePriority", response.getReturnValue());
                //Initialize dropdown with values
                var opts1 = [{
                    "class": "optionClass",
                    selected: "true"
                }];;
                var globalrClosurePriority = component.get("v.globalrClosurePriority");
                for (var i = 0; i < globalrClosurePriority.length; i++) {
                    opts1.push({
                        "class": "optionClass",
                        label: globalrClosurePriority[i],
                        value: globalrClosurePriority[i]
                    });
                }
                component.find("closurePriorityId").set("v.options", opts1);
				component.set("v.EhsFinidng.ClosurePriority__c","30");
                
            }
        });
        $A.enqueueAction(closurePriority);
		
		var fetchUseraction = component.get("c.fetchUser");
        fetchUseraction.setCallback(this, function(response) {
            var state = response.getState();
            if (state === "SUCCESS") {
                var storeResponse = response.getReturnValue();
               // set current user information on userInfo attribute
                component.set("v.userInfo", storeResponse);
            }
        });
        $A.enqueueAction(fetchUseraction);
		if(component.get("v.EhsFindingsId")==undefined || component.get("v.EhsFindingsId")==''){
		helper.saveimage(component,event);
		}
            
    },
     Cancel : function(component, event){
	  var findingrecordId = component.get("v.EhsFindingsId");
         if(findingrecordId!=undefined ||findingrecordId!=null){
		alert('@@findingrecordId@@'+findingrecordId);
        var action = component.get("c.cancelFindings");
        action.setParams({ 
            parentIdvalue : findingrecordId
        });
        action.setCallback(this,function(response){
            if(component.isValid() && response.getState() === "SUCCESS"){
               if((typeof sforce != 'undefined') && sforce && (!!sforce.one))
            {
 				sforce.one.back(true);            } 
			else {
                window.location.href = 'https://tipeurope--full.lightning.force.com/lightning/o/MTX_Finding__c/list?filterName=Recent&0.source=alohaHeader';
				}
            }
        });
         $A.enqueueAction(action);
 
         }
         else{
              window.location.href = 'https://tipeurope--full.lightning.force.com/lightning/o/MTX_Finding__c/list?filterName=Recent&0.source=alohaHeader';

         }
                
       
     },
    SaveFindings : function(component, event,helper){
	helper.mandatoryCheck(component);
       
     },

	deleteImagesofFindings :  function(component, event, helper){
        component.set("v.findingPopup",true);
        //helper.deleteImagesHelper(component);
        
    },
    deleteFindingImages :  function(component, event, helper){
        
        helper.deleteImagesHelper(component);
        
    },
    closeModel: function(component, event, helper) {
      // for Hide/Close Model,set the "isOpen" attribute to "Fasle"  
      component.set("v.findingPopup", false);
   },
    handleUploadFinished: function (cmp, event) {
        //Get the list of uploaded files
        var uploadedFiles = event.getParam("files");
        //Show success message – with no of files uploaded
        var toastEvent = $A.get("e.force:showToast");
        toastEvent.setParams({
            "title": "Success!",
            "type" : "success",
            "message": uploadedFiles.length+" files has been uploaded successfully!"
        });
        toastEvent.fire();
		document.getElementById("count--").innerHTML = uploadedFiles.length;
         
        //$A.get('e.force:refreshView').fire();
         
        //Close the action panel
       // var dismissActionPanel = $A.get("e.force:closeQuickAction");
        //dismissActionPanel.fire();
    },
	
})