({
	mandatoryCheck : function(component){
	var findCorrectiveActionError = component.find("findCorrectId");
	var findCategoryError  = component.find("findCategoryId");
	var findDescError = component.find("findDescId");
	var closurePriorityError = component.find("closurePriorityId");
	var findingTypeError = component.find("findingTypeId");
	var siteError = component.find("siteId");
	var errorCheck = false;
	var userinfo = component.get("v.userInfo");
	//alert('@@ProfileName@@'+userinfo.Profile.Name);
	 if($A.util.isEmpty(component.get("v.EhsFinidng.FindingCorrectiveAction__c")) || $A.util.isUndefinedOrNull(component.get("v.EhsFinidng.FindingCorrectiveAction__c"))){
	 $A.util.addClass(findCorrectiveActionError, 'slds-has-error');
                findCorrectiveActionError.set("v.errors", [{ message: " Finding Corrective Action is Mandatory " }]);
		errorCheck = true;
	 }
	 else{
		$A.util.removeClass(findCorrectiveActionError, 'slds-has-error');
                findCorrectiveActionError.set("v.errors", null);
	 
	 }
	 if($A.util.isEmpty(component.get("v.EhsFinidng.FindingCategory__c")) || $A.util.isUndefinedOrNull(component.get("v.EhsFinidng.FindingCategory__c"))){
	 $A.util.addClass(findCategoryError, 'slds-has-error');
                findCategoryError.set("v.errors", [{ message: " Finding Category is Mandatory " }]);
	 errorCheck = true;
	 }
	 else{
		$A.util.removeClass(findCategoryError, 'slds-has-error');
                findCategoryError.set("v.errors", null);
	 
	 }
	 if($A.util.isEmpty(component.get("v.EhsFinidng.FindingDescription__c")) || $A.util.isUndefinedOrNull(component.get("v.EhsFinidng.FindingDescription__c"))){
	 $A.util.addClass(findDescError, 'slds-has-error');
                findDescError.set("v.errors", [{ message: " Finding Desccription is Mandatory " }]);
	 errorCheck = true;
	 }
	 else{
		$A.util.removeClass(findDescError, 'slds-has-error');
                findDescError.set("v.errors", null);
	 
	 }
	 if($A.util.isEmpty(component.get("v.EhsFinidng.ClosurePriority__c")) || $A.util.isUndefinedOrNull(component.get("v.EhsFinidng.ClosurePriority__c")) || component.get("v.EhsFinidng.ClosurePriority__c")==null|| component.get("v.EhsFinidng.ClosurePriority__c")==''){
         $A.util.addClass(closurePriorityError, 'slds-has-error');
                closurePriorityError.set("v.errors", [{ message: " Closure Priority is Mandatory " }]);
	 errorCheck = true;
	 }
	 else{
		$A.util.removeClass(closurePriorityError, 'slds-has-error');
                closurePriorityError.set("v.errors", null);
	 
	 }
	 if($A.util.isEmpty(component.get("v.EhsFinidng.SiteRef__c")) || $A.util.isUndefinedOrNull(component.get("v.EhsFinidng.SiteRef__c"))){
	 $A.util.addClass(siteError, 'slds-has-error');
                siteError.set("v.errors", [{ message: " Site is Mandatory " }]);
	 errorCheck = true;
	 }
	 else{
		$A.util.removeClass(siteError, 'slds-has-error');
                closurePriorityError.set("v.errors", null);
	 
	 }
	 if($A.util.isEmpty(component.get("v.EhsFinidng.FindingType__c")) || $A.util.isUndefinedOrNull(component.get("v.EhsFinidng.FindingType__c"))){
	 $A.util.addClass(findingTypeError, 'slds-has-error');
                findingTypeError.set("v.errors", [{ message: " Finding Type is Mandatory " }]);
	 errorCheck = true;
	 }
	 else{
		$A.util.removeClass(findingTypeError, 'slds-has-error');
                findingTypeError.set("v.errors", null);
	 
	 }
	 if(component.get("v.EhsFinidng.ClosurePriority__c")!=null && component.get("v.EhsFinidng.ClosurePriority__c")==60 && (userinfo.Profile.Name!='System Administrator' && userinfo.Profile.Name!='MTX_EHS Manager' && userinfo.Profile.Name!='MTX_EHS Director' ) ){
	 $A.util.addClass(closurePriorityError, 'slds-has-error');
                closurePriorityError.set("v.errors", [{ message: "Employees can not change the ClosurePriority to 60" }]);
	 errorCheck = true;
	 }
	 else{
		$A.util.removeClass(closurePriorityError, 'slds-has-error');
                closurePriorityError.set("v.errors", null);
	 
	 }
	 if(errorCheck == false){
	this.savefindings(component);
	}
	},
	savefindings:  function(component){
	 var findingobj = component.get("v.EhsFinidng");
         var action1 = component.get("c.saveEhsFindings");
         findingobj.sobjectType = 'MTX_Finding__c';
		 if(component.get("v.EhsFindingsId") !=undefined || component.get("v.EhsFindingsId") !=null){
	findingobj.Id = component.get("v.EhsFindingsId");
	
	}
        action1.setParams({
            "findobj": findingobj});
        action1.setCallback(this, function(resp) {
            var stateOfAction1 = resp.getState();
            if (stateOfAction1 === "SUCCESS") {
                window.open('/lightning/o/MTX_Finding__c/list?filterName=Recent', "_parent");
            } else {
                if (stateOfAction1 === "ERROR") {
                    var error = resp.getError();
                    component.set("v.message", error[0].message);
                }
            }
        });
        $A.enqueueAction(action1);
	},
	   saveimage: function(component,event){
	   
	   var findingobj = component.get("v.EhsFinidng");
          // var id=event.target.id;
         var action1 = component.get("c.saveEhsFindings");
         findingobj.sobjectType = 'MTX_Finding__c';
        action1.setParams({
            "findobj": findingobj});
        action1.setCallback(this, function(resp) {
            var stateOfAction1 = resp.getState();
			var ehsId = resp.getReturnValue();
			component.set("v.EhsFindingsId",ehsId);
			alert(component.get("v.EhsFindingsId"));
            if (stateOfAction1 === "SUCCESS") {
              //this.saveImagefiles(component,event,ehsId);
            } else {
                if (stateOfAction1 === "ERROR") {
                    var error = resp.getError();
                    component.set("v.message", error[0].message);
                }
            }
        });
        $A.enqueueAction(action1);
	   
	   
	   },
	   deleteImagesHelper : function(component){
        console.log('in Helper Delete');
        //var id=event.target.id;
        //var that = this;
        //deleteId = id.split('--');
		//var deleteId = component.get("v.EhsFindingsId");
       // console.log('deleteId'+deleteId);
        var findingrecordId = component.get("v.EhsFindingsId");
        console.log('findingrecordId'+findingrecordId);
        //console.log(component.get("v.selectedImages").length);
        //if(component.get("v.selectedImages").length == 0){
          //  alert('Please select the file to delete');
        //}
        var action = component.get("c.deleteImages");
        action.setParams({ 
            //imagesIdsList : component.get("v.selectedImages"),
            parentIdvalue : findingrecordId
        });
        action.setCallback(this,function(response){
            if(component.isValid() && response.getState() === "SUCCESS"){
                console.log('response from delete Images');
                console.log(response.getReturnValue());
                var Icount = 0;
                component.set("v.findingPopup",false);
                component.set("v.imageCount",Icount);
                console.log('parent ID before calling get images in delete method'+findingrecordId);
				 component.set("v.imageCountMap",Icount);
                alert('Images deleted successfully!');
               // var findingid = 'count--'+findingrecordId;
              //  console.log('------->@'+findingid+'@');
                document.getElementById("count--").innerHTML = Icount;
            }
        });
         $A.enqueueAction(action);
    },
	
})