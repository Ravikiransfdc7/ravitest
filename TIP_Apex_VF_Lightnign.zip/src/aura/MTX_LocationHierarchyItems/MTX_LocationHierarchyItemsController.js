({
    doInit: function(component, event, helper) {
        //debugger;
        var locationHierarchy = component.get("v.locationHierarchy");
        var parentNode = component.get("v.parentNode");
        if(locationHierarchy && locationHierarchy.length > 0){
            for(var item in locationHierarchy){
                if(locationHierarchy[item].key == parentNode){
                    component.set("v.childNodeList", locationHierarchy[item].value);  
                    break;
                }
            }
        }
        
    },
    selectAll : function(component, event, helper) {
        //debugger;
        //var chkBox1 = component.find("chkboxRegion");
        //var chkBox = event.currentTarget;
        var chkBox = event.source;
        if(chkBox && chkBox.getElements() && chkBox.getElements()[0].size > 0 
           && chkBox.getElements()[0].parentNode && chkBox.getElements()[0].parentNode.nextSibling
           && chkBox.getElements()[0].parentNode.nextSibling.nodeName == "UL" 
           && chkBox.getElements()[0].parentNode.nextSibling.getElementsByTagName("input")) {
            for (var i = 0; i < chkBox.getElements()[0].parentNode.nextSibling.getElementsByTagName("input").length; i++){
                //debugger;
                if(chkBox.getElements()[0].type == "checkbox" && chkBox.getElements()[0].checked){
                    chkBox.getElements()[0].parentNode.nextSibling.getElementsByTagName("input")[i].checked = true;    
                }else{
                    chkBox.getElements()[0].parentNode.nextSibling.getElementsByTagName("input")[i].checked = false;    
                }
                
            }    
        }
	},
    doToggle : function(component, event, helper) {
        //debugger;
        if(event.currentTarget && event.currentTarget.childNodes["0"]
           && event.currentTarget.childNodes["0"].lastChild.attributes["0"] 
           && event.currentTarget.childNodes["0"].lastChild.attributes["0"].nodeValue) {
            var imageUrl = event.currentTarget.childNodes["0"].lastChild.attributes["0"].nodeValue;
            var urlmap=imageUrl.split("#");
            var currentImage = urlmap[1];
            if(currentImage == "chevronright")
            {
                event.currentTarget.childNodes["0"].lastChild.attributes["0"].nodeValue = imageUrl.replace("chevronright","chevrondown")
                if(event.currentTarget && event.currentTarget.parentElement && event.currentTarget.parentElement.nextElementSibling) {
                    event.currentTarget.parentElement.nextElementSibling.hidden = false;    
                }
            }
            else
            {
                event.currentTarget.childNodes["0"].lastChild.attributes["0"].nodeValue = imageUrl.replace("chevrondown","chevronright")
                if(event.currentTarget && event.currentTarget.parentElement && event.currentTarget.parentElement.nextElementSibling) {
                    event.currentTarget.parentElement.nextElementSibling.hidden = true;    
                }
                
            }     
        }
             
        
    }
})