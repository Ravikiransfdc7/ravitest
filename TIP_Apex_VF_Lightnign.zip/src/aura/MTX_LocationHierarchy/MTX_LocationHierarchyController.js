({
	doInit : function(component, event, helper) {
        //debugger;
        var getLocationHierarchy = component.get("c.getLocationHierarchy");
        getLocationHierarchy.setParams({
            "inspectionId" : component.get("v.recordId")
        });
        var getAllParentLocations = component.get("c.getAllParentLocations");
        
        getAllParentLocations.setCallback(this, function(a) {
            //debugger;
            if(a.getState() == 'SUCCESS' && a.getReturnValue()){
                component.set("v.parentLocationList",a.getReturnValue());
            }
        });
        
        getLocationHierarchy.setCallback(this, function(a) {
            if(a.getState() == 'SUCCESS' && a.getReturnValue()){
               	var result = a.getReturnValue();
                    var locationHierarchyArray = [];
                    for(var item in result) {
                        var key = item;
                        var value = result[item];
                        locationHierarchyArray.push ({
                            key: key,
                            value: value
                        }); 
                    }
                component.set("v.locationHierarchyMap",locationHierarchyArray);
                
                $A.enqueueAction(getAllParentLocations);
                //debugger;
                
            }
        });
        $A.enqueueAction(getLocationHierarchy);
        
    },
    
    showSpinner : function (component, event, helper) {
        var toggleText = component.find("spinner");
        $A.util.removeClass(toggleText,'toggle');
    },
    
    hideSpinner : function (component, event, helper) {
        var toggleText = component.find("spinner");
        $A.util.addClass(toggleText,'toggle');
    },
    
    createInspectionSites : function(component, event, helper) {
        //debugger;
        var selectedChkBox = document.getElementsByClassName('location-checkBox');
        var listCheckboxes = [];
        for(var i = 0; i < selectedChkBox.length; i++) {
            if(selectedChkBox[i].checked) {
               listCheckboxes.push(selectedChkBox[i].value); 
            }    
        }
        var recordId = component.get("v.recordId");
        var insertInspectionSites = component.get("c.insertInspectionSites");
        insertInspectionSites.setParams({
            "inspectionId" : recordId,
            "locationList" : listCheckboxes
        });
        insertInspectionSites.setCallback(this, function(response) {
            var state = response.getState();
            if (state === "SUCCESS") {
                $A.get('e.force:refreshView').fire();
                //console.log('Record Inserted');
            } 
        });
        $A.enqueueAction(insertInspectionSites);  
        
        
    }
})